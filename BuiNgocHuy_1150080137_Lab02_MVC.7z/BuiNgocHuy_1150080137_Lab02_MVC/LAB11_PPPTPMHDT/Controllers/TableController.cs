﻿using Microsoft.AspNetCore.Mvc;

namespace BuiNgocHuy_1150080137_Lab02_MVC.Controllers
{
    public class TableController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
